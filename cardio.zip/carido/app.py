from flask import Flask, request, render_template
import pickle
import numpy as np
import pandas as pd
app = Flask(__name__)

# Load your trained model
model = pickle.load(open('model.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get form data
    age = int(request.form['age'])
    resting_bp = float(request.form['resting_bp'])
    cholesterol = float(request.form['cholesterol'])
    fasting_bs = float(request.form['fasting_bs'])
    max_hr = float(request.form['max_hr'])
    oldpeak = float(request.form['oldpeak'])
    sex = request.form['sex']
    chest_pain = request.form['chest_pain']
    resting_ecg = request.form['resting_ecg']
    exercise_angina = request.form['exercise_angina']
    st_slope =request.form['st_slope']

    # Prepare the input for the model
    features = np.array([[age, resting_bp, cholesterol, fasting_bs, max_hr, oldpeak, sex, chest_pain, resting_ecg, exercise_angina, st_slope]])
    features = pd.DataFrame({
        'Age': [age],
        'RestingBP': [resting_bp],
        'Cholesterol': [cholesterol],
        'FastingBS': [fasting_bs],
        'MaxHR': [max_hr],
        'Oldpeak': [oldpeak],
        'Sex': [sex],
        'ChestPainType': [chest_pain],
        'RestingECG': [resting_ecg],
        'ExerciseAngina': [exercise_angina],
        'ST_Slope': [st_slope]
    })

    # Make prediction
    prediction = model.predict(features)
    print("Input Features:", features)
    print("Prediction:", prediction[0])
    if prediction == 1:
        message = 'There is a chance of cardiac arrest.'
    else:
        message = 'You are normal.'

    # Return the result to the HTML page
    return render_template('index.html', prediction_text=message)

    # Return the result to the HTML page
    return render_template('index.html', prediction_text=f'Prediction: {prediction[0]}')

if __name__ == "__main__":
    app.run(debug=True)
