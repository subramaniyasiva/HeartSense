import boto3
import time


athena_client = boto3.client('athena')
print("sucessfully connected")


query = 'SELECT * FROM "parquettest"."batchdata" limit 1;'
output_location = 's3://aiprototype/output/'


response = athena_client.start_query_execution(
    QueryString=query,
    ResultConfiguration={'OutputLocation': output_location}
)

query_execution_id = response['QueryExecutionId']


while True:
    status = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
    state = status['QueryExecution']['Status']['State']
    if state in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
        break
    time.sleep(1)


if state == 'SUCCEEDED':
    
    result = athena_client.get_query_results(QueryExecutionId=query_execution_id)
    print("down is the result")
    print(result)
    
else:
    print(f"Query failed with state: {state}")

